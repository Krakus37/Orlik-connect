
export default function Home() {
  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>OrlikConnect</h1>
      <p>Aplikacja do umawiania się na mecze w Skierniewicach</p>
    </div>
  );
}
