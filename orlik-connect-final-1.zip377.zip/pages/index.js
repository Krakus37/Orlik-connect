
export default function Home() {
  return (
    <main style={{ padding: 20, fontFamily: 'Arial, sans-serif' }}>
      <h1>OrlikConnect</h1>
      <p>Twoja aplikacja do umawiania się na mecze w Skierniewicach</p>
    </main>
  );
}
